<?php
include 'inc/header.php';
?>
<body>
    <div class="container site-section" id="FeatureCakesContainer">
        <h1 id="FeatureCakesText">Failed </h1>
        <h1>Purchase Failed. Please fill the informations properly and Try again. Thank You</h1></div>
    <?php
    include 'inc/footer.php';
    ?>