<?php
include 'inc/header.php';
?>
    <div class="container site-section" id="FeatureCakesContainer">
        <h1 id="FeatureCakesText">Success </h1>
        <h1>Your Product Has been successfully Purchased. it will be delivered within two working days in your address. Thank You for shopping. </h1><i class="glyphicon glyphicon-heart" id="HeartLogo"></i> <a class="btn btn-primary" role="button" href="orderdetails.php">View Orders</a></div>
        
<?php
    include 'inc/footer.php';
    ?>