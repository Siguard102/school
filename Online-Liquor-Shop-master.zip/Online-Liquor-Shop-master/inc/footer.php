       <footer>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="footer-nav">
                       
                            
                        </div>
                        
                        <br>
                        
                    </div>
                </div>
            </div>
        </footer> <!--   end footer area     -->
    </body>
</html>
