﻿<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2 style="color: #ff0039;"> Dashbord</h2>
                <div class="block" style="color: #ff0039;">               
                  Welcome To Your Liquor Admin Panel        
                </div> <br/>
                <div class="block" style="color: #ff0039; font-style: italic;">               
                 "Here You Will be Able to Add Liquor in your Website & also Your can Add new Category."  
                </div>
            </div>
        </div>
<?php include 'inc/footer.php';?>