 <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
    <div id="site_info">
        <p>
         &copy; <a href=""></a>
        </p>
    </div>
</body>
</html>
