<div class="grid_2">
    <div class="box sidemenu">
        <div class="block" id="section-menu">
            <ul class="section menu">
                <li><a class="menuitem" style="color: #ff0039;">Category Option</a>
                    <ul class="submenu">
                        <li><a href="catadd.php" style="color: #ff0039;">Add Category</a> </li>
                        <li><a href="catlist.php" style="color: #ff0039;">Category List</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem" style="color: #ff0039;">Liquor Option</a>
                    <ul class="submenu">
                        <li><a href="productadd.php" style="color: #ff0039;">Add Liquor</a> </li>
                        <li><a href="productlist.php" style="color: #ff0039;">Liquor List</a> </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>