<?php
    include 'inc/header.php';
    ?>
    <div class="container site-section" id="why">
        <h1 style="color: #ff0039;">Contact Us</h1>
        <div class="main2">
        <div class="row" id="WhyChooseUsBackground">
            <div class="col-md-4 item">
                <h2 class="text-left" id="WhyChooseUsText" style="color: #ff0039;">Names </h2>
                <p class="text-left Names" id="GreatTestText" style="color: #ff0039;">EMRUL KAISAR</p>
                <p class="text-left Names" id="GreatTestText" style="color: #ff0039;">MALIHA BINTE NUR</p>
             
            </div>
            <div class="col-md-4 item">
                <h2 class="text-left">Ids </h2>
                <p class="text-left ids" id="HealthyText" style="color: #ff0039;">143 0333 042 </p>
                <p class="text-left ids" id="HealthyText" style="color: #ff0039;">151-0772-642 </p>
            
            </div>

        </div>
    </div>
</div>
<?php
include 'inc/footer.php';
?>